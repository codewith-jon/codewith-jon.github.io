// hello,, we are going to write a cpp program to round off any number
#include <iostream>
#include "myInfo.h"// this is just my header file,,you can avoid using this
// you can get this code from the link in the description below
int main()
{
	dispalyMyInfo();//also this ... dont include in your program
	
	int tempNum, tempCheck, roundNum;
	float num;
	
	std::cout<<"\n\nEnter any number "<<std::endl;
	std::cin>>num;
	
	if(num>0)
	{
		tempNum = num *10;
		tempCheck = tempNum % 10;
		
		if(tempCheck >=5)
		{
			roundNum = num;
			roundNum ++;
			}
			else
			{
				roundNum = num;
				}
				std::cout<<"The whole number after rounding off is = "<<roundNum;
		}
		else if(num<0)
		{
			num =-(num);
			tempNum = num * 10;
			tempCheck = tempNum % 10;
			
			if(tempCheck >=5)
			{
				roundNum = num;
				roundNum --;
			}
			else
			{
				roundNum = num;
			}
			std::cout<<"The whole number after rounding off is = "<<-roundNum<<std::endl;
			
		}
		else
		{
			std::cout<<"The number is zero";
		}
	
	
	
	
	
	
	happyCoding();
	
	return 0;
	} 
