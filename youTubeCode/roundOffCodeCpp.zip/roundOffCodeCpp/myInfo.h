#include <iostream>
void happyCoding()
{
	std::cout<<"\n\nhaPpyCoDinG\n   codewj \n\t@2021";
}
void dispalyMyInfo()
{
std::cout<<"*******************************from CodeWJ*******************************\n";
std::cout<<"aUthor----- jonWaithira ---- juniorSoftwAre Engineer\n";
std::cout<<"toPic-------------------- roundingOff\n";
std::cout<<"contact   --------- jongachatha@gmail.com\n";
std::cout<<"codewj HelpDesk --------- help.codewj@gmail.com\n";

	
	
}
