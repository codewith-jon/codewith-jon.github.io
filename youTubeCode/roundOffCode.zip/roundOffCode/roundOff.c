#include <stdio.h>
#include "myInfo.h"
int main()
{
	// **********displayInfoAboutCodeWJ****************************
								displayCodewjInfo();// you can delete this function
	//**************************************************************
	int tempNum, tempCheck, roundNum; //temp means temporary
	float num;
	
	printf("Enter any number \n");
	scanf("%f",&num);
	
	if(num>0)
	{
		tempNum = num *10;
		tempCheck = tempNum % 10;
		if(tempCheck >=5)
		{
			roundNum = num;
			roundNum ++;
		}
		else
		{
			roundNum = num;
		}
		printf("The whole number after rounding off is = %d", roundNum);
	}
	// now let check for numbers less than zero
	else if(num<0)
	{
		num = -(num);
		tempNum = num *10;
		tempCheck = tempNum % 10;
		if(tempCheck >=5)
		{
			roundNum = num;
			roundNum --;
			}
			else
			{
				roundNum =num;
				}
				printf("The number after rounding off is = -%d ", roundNum);//please note the - sign in the %d
	}
	else
	{
		printf("Number is zero");
		}
	 happyCoding();// also this is not need if you are working on an assignment
	    
	return 0;
	}
