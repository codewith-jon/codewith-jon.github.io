#include <stdio.h>
void displayCodewjInfo()
{
	printf("*******************************from codeWj****************************\n* author jonWaithira - junior softWare Engineer\n* code---roundIngOff\n* contact ---john ----- jongachatha@gmail.com\n* contact --- codewj HelpDesk ------   help.codewj@gmail.com\n* visit my website -------- https://www.codewj.ml");
	printf("\n\n");
}
void happyCoding()
{
	printf("\n\n\n\n\n\n\n\n\n\n\n#haPpYCoDing \n   codewj\n\t@2021");
	
	}

