/* from codeWj
 * author johnWaithira - junior softWare Engineer
 * contact ---john ----- jongachatha@gmail.com
 * contact ---codewj HelpDesk ------help.codewj@gmail.com
 * visit my website -------- https://www.codewj.ml 
*/
#include <iostream>
#include "header.h"// including the header file

using namespace std;

	int main()
	{
		int num1, num2, ans;
		cout<<"Enter first number"<<endl;
		cin>>num1;
		cout<<"Enter second number"<<endl;
		cin>>num2;
		ans = addTwoInts(num1, num2);// function calling
		cout<<"The sum is "<<ans;
		return 0;
		}
		
	
		
		
		
		
		
		
		
		
		
