/* from codeWj
 * author johnWaithira - junior softWare Engineer
 * code---string copy
 * contact ---john ----- jongachatha@gmail.com
 * contact ---codewj HelpDesk ------help.codewj@gmail.com
 * visit my website -------- https://www.codewj.ml 
*/
#include <iostream>
#include <string.h>

int main()
{
	char strOne[20], strTwo[20];
	
	std::cout<<"Enter the first string"<<std::endl;
	std::cin>>strOne;
	
	strcpy(strTwo,strOne);
	
	std::cout<<"string Two is "<<strTwo;
	
	return 0;
	}

 




















































































		
		
		
		
		
		
		
