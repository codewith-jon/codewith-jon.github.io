


int Factorial(int number)
{
	int factorial =1, i;
	for(i =1 ; i<=number; i++)
	{
		factorial = factorial * i;

		}
	
	return factorial;
	}
