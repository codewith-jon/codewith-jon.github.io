/* from codeWj
 * author johnWaithira - junior softWare Engineer
 * contact ---john ----- jongachatha@gmail.com
 * contact ---codewj HelpDesk ------help.codewj@gmail.com
 * visit my website -------- https://www.codewj.ml 
*/

#include <iostream>
#include "factorial.h"

int main()
{
	int  num;
	std::cout<<"Enter a positive interger "<<std::endl;
	std::cin>>num;
	std::cout<<"The factorial of "<<num<<" is "<<Factorial(num)<<std::endl; 
	
	return 0;
	}

















































		
		
		
		
		
		
		
