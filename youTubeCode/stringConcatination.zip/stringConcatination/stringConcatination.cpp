/* from codeWj
 * author johnWaithira - junior softWare Engineer
 * code---string concatination
 * contact ---john ----- jongachatha@gmail.com
 * contact ---codewj HelpDesk ------help.codewj@gmail.com
 * visit my website -------- https://www.codewj.ml 
*/
#include <iostream>
#include <string.h>

int main()
 {
	 char strOne[20], strTwo[20], *strThree;
	 std::cout<<"Enter first string"<<std::endl;
	 std::cin>>strOne;
	 std::cout<<"Enter second string "<<std::endl;
	 std::cin>>strTwo;
	 strThree = strcat(strOne, strTwo);
	 std::cout<<"String three after concatination "<<strThree<<std::endl;
	 	 return 0;
	 	 }
 

 
 
 
 
 
 
 
 
 
 
 
 











































































































		
		
		
		
		
		
		
