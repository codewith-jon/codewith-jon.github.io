

/* from codeWj
 * author johnWaithira - junior softWare Engineer
 * code---string length
 * contact ---john ----- jongachatha@gmail.com
 * contact ---codewj HelpDesk ------help.codewj@gmail.com
 * visit my website -------- https://www.codewj.ml 
*/
#include <iostream>
#include <string.h>

int main()
{
	char name[50];
	int len;
	std::cout<<"Enter your name  : "<<std::endl;
	std::cin>>name;
	
	len = strlen(name);
	
	std::cout<<"The length of "<<name<<" is "<<len;
	
	return 0;
	}

 


































































































		
		
		
		
		
		
		
